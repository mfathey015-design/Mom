#!/usr/bin/env python3
from pathlib import Path
import base64
import json
import os
import urllib.error
import urllib.request
from datetime import date

ROOT = Path(__file__).resolve().parent
LICENSE_URL = os.environ.get(
    "ELMASRY_LICENSE_URL",
    "https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json",
)
DEVELOPER_URL = "https://t.me/mfathey466"

COLORS = {
    "red": "\033[91m", "green": "\033[92m", "yellow": "\033[93m",
    "blue": "\033[94m", "magenta": "\033[95m", "cyan": "\033[96m",
    "reset": "\033[0m",
}

def say(message: str, color: str = "cyan", *, end: str = "\n") -> None:
    print(f"{COLORS[color]}{message}{COLORS['reset']}", end=end, flush=True)

def _print_error(message: str) -> None:
    say(f"\n[ERROR] {message}", "red")
    say("For subscription or support, contact: @mfathey466", "yellow")
    say(f"Telegram: {DEVELOPER_URL}\n", "cyan")

def validate_license() -> bool:
    say("╔════════════════════════════════════════════╗", "cyan")
    say("║       ELMASRY VIP - License Check          ║", "magenta")
    say("╚════════════════════════════════════════════╝", "blue")
    try:
        say("\nEnter your subscription key: ", "yellow", end="")
        key = input().strip()
    except (EOFError, KeyboardInterrupt):
        say("", "cyan")
        return False

    if not key:
        _print_error("No subscription key was entered.")
        return False

    # License validation runs without a connection-status message.
    try:
        request = urllib.request.Request(
            LICENSE_URL,
            headers={"User-Agent": "ELMASRY-VIP-Termux/1.0", "Accept": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            licenses = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        _print_error("Could not connect to the license server. Check your internet and try again.")
        say(f"Details: {exc}", "cyan")
        return False

    record = licenses.get(key) if isinstance(licenses, dict) else None
    if not isinstance(record, dict) or record.get("status") != "ok":
        _print_error("The key is invalid or inactive.")
        return False

    expiry = str(record.get("expiry", "")).strip()
    try:
        expiry_date = date.fromisoformat(expiry)
    except ValueError:
        _print_error("The subscription expiry date is invalid.")
        return False

    if expiry_date < date.today():
        _print_error(f"The subscription expired on {expiry}.")
        return False

    say("\nSubscription key verified successfully.", "green")
    # Ignore remote message text because it may contain Arabic.
    say(f"Subscription is valid until {expiry}", "cyan")
    return True


if not validate_license():
    raise SystemExit(1)

# Decrypt the payload only after subscription validation succeeds.
from Crypto.Cipher import AES
from Crypto.PublicKey import ECC
from Crypto.Signature import eddsa

payload_path = ROOT / "payload.enc"
signature_path = ROOT / "payload.sig"
public_key_path = ROOT / "payload.pub"
payload = payload_path.read_bytes()
try:
    public_key = ECC.import_key(public_key_path.read_bytes())
    eddsa.new(public_key, "rfc8032").verify(payload, signature_path.read_bytes())
    source = AES.new(
        base64.b85decode("(ze;<4zx75z>y0#CTao5gn5|Um~<Wrvh2rT=#hxB"),
        AES.MODE_GCM,
        nonce=payload[:12],
    ).decrypt_and_verify(payload[28:], payload[12:28]).decode("utf-8")
except Exception as exc:
    raise RuntimeError("Encrypted tool integrity check failed") from exc

# Store the user's working folders at the root of shared internal storage.
# Termux exposes this location through ~/storage/shared after storage permission
# has been granted with: termux-setup-storage
_phone_storage = Path("/storage/emulated/0")
if not _phone_storage.is_dir() or not _phone_storage.exists():
    raise RuntimeError(
        "Phone storage is unavailable. Run termux-setup-storage, then restart the tool."
    )
WORK_ROOT = _phone_storage / "PAK TOOL"
try:
    WORK_ROOT.mkdir(parents=True, exist_ok=True)
except OSError as exc:
    raise RuntimeError(
        "Cannot write to phone storage. Run termux-setup-storage, then restart the tool."
    ) from exc

for name in (
    "ORIGINAL_PAK", "UNPACKED_FILES", "EDITTED_FILES", "EDIT_PAK", "REPACKED_PAK",
    "FOUND_FILES", "Original_OBB", "unpacked_OBB", "Repacked_OBB", "LUA_ORIGINAL",
    "DECOMPILED_LUA", "COMPILED_LUA", "LUA_REPORTS", "SM4_FINDER_SCAN", "PAK",
    "EDIT", "RESULT",
):
    (WORK_ROOT / name).mkdir(parents=True, exist_ok=True)

os.environ["OBB_PAK_TOOL_BASE_PATH"] = str(WORK_ROOT)
namespace = {"__name__": "embedded", "__file__": "<encrypted>"}
exec(compile(source, "<encrypted obb_pak_tool>", "exec"), namespace, namespace)
entrypoint = namespace.get("main")
if not callable(entrypoint):
    raise RuntimeError("Original Tool 2 entrypoint not found")
entrypoint()
