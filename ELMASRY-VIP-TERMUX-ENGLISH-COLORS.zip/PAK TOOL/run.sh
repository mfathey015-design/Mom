#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
clear
exec python obb_pak_tool.py
