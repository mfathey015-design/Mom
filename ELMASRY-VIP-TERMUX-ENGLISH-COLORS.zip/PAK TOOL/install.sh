#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python -y
pip install -r requirements.txt
exec bash run.sh
