#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python -y
pip install -r requirements.txt
printf '\033[92m\nInstallation complete. Start the tool with: bash run.sh\033[0m\n'
