# ELMASRY VIP — النسخة المشفرة

الأداة تتحقق من مفتاح الاشتراك من ملف JSON قبل فك وتشغيل `payload.enc`.

## التشغيل على Termux

```bash
pkg update -y
pkg install python git -y
git clone رابط-مستودع-GitHub
cd "PAK TOOL"
pip install -r requirements.txt
bash run.sh
```

When prompted, enter your subscription key. The prompts and status messages are displayed in English with colored terminal lines. إذا كان صحيحًا وغير منتهٍ تفتح الأداة، وإذا كان غير صحيح تظهر رسالة التواصل مع المطور `@mfathey466` ورابط تيليجرام مباشر.

## تغيير رابط ملف التراخيص

الرابط الافتراضي هو:

```text
https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json
```

ويمكن تغييره مؤقتًا قبل التشغيل:

```bash
export ELMASRY_LICENSE_URL="https://example.com/licenses.json"
bash run.sh
```

صيغة JSON المتوقعة:

```json
{
  "KEY-123": {
    "status": "ok",
    "expiry": "2027-12-31",
    "message": "الاشتراك مفعل"
  }
}
```

> ملاحظة: ملف JSON العام مناسب للتجربة، لكنه ليس نظام حماية قويًا؛ لأن المفاتيح يمكن قراءتها من رابط GitHub. للحماية التجارية الأفضل استخدام API خاص مع قاعدة بيانات.
