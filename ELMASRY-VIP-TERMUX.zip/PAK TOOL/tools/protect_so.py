#!/usr/bin/env python3
"""Protect a shared object without modifying the original ELF.

The encrypted file is an AES-GCM container. Decryption is explicit and writes
only to the requested temporary/output path. This is packaging protection, not
an attempt to alter the ELF binary.
"""
from __future__ import annotations
import argparse, getpass, hashlib, os, pathlib, secrets, sys
from Crypto.Cipher import AES

MAGIC = b"ELMASRY-SO\x01"
SALT_SIZE = 16
NONCE_SIZE = 12
TAG_SIZE = 16


def key_from_password(password: str, salt: bytes) -> bytes:
    return hashlib.scrypt(password.encode(), salt=salt, n=2**14, r=8, p=1, dklen=32)


def pack(src: pathlib.Path, dst: pathlib.Path, password: str) -> None:
    raw = src.read_bytes()
    salt = secrets.token_bytes(SALT_SIZE)
    nonce = secrets.token_bytes(NONCE_SIZE)
    cipher = AES.new(key_from_password(password, salt), AES.MODE_GCM, nonce=nonce)
    encrypted, tag = cipher.encrypt_and_digest(raw)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(MAGIC + salt + nonce + tag + encrypted)


def unpack(src: pathlib.Path, dst: pathlib.Path, password: str) -> None:
    blob = src.read_bytes()
    header = len(MAGIC) + SALT_SIZE + NONCE_SIZE + TAG_SIZE
    if len(blob) < header or blob[:len(MAGIC)] != MAGIC:
        raise ValueError("Invalid protected SO container")
    pos = len(MAGIC)
    salt = blob[pos:pos+SALT_SIZE]; pos += SALT_SIZE
    nonce = blob[pos:pos+NONCE_SIZE]; pos += NONCE_SIZE
    tag = blob[pos:pos+TAG_SIZE]; pos += TAG_SIZE
    cipher = AES.new(key_from_password(password, salt), AES.MODE_GCM, nonce=nonce)
    raw = cipher.decrypt_and_verify(blob[pos:], tag)
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(raw)
    os.chmod(dst, 0o755)


def main() -> int:
    ap = argparse.ArgumentParser(description="Protect or restore a .so file")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("pack", "unpack"):
        p = sub.add_parser(name)
        p.add_argument("source", type=pathlib.Path)
        p.add_argument("destination", type=pathlib.Path)
    args = ap.parse_args()
    password = os.environ.get("ELMASRY_SO_PASSWORD") or getpass.getpass("SO protection password: ")
    if not password:
        print("Password cannot be empty", file=sys.stderr)
        return 2
    try:
        if args.cmd == "pack":
            pack(args.source, args.destination, password)
        else:
            unpack(args.source, args.destination, password)
    except Exception as exc:
        print(f"Failed: {exc}", file=sys.stderr)
        return 1
    print(args.destination)
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
