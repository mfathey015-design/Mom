# ELMASRY VIP — Termux Edition

The tool validates a subscription key from a JSON license file before starting the encrypted payload.

## Install and run on Termux

```bash
pkg update -y
pkg install python wget unzip -y
python -m pip install -r requirements.txt
bash run.sh
```

The tool will ask for a subscription key and connect to the license server.

## License endpoint

Default endpoint:

```text
https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json
```

To use another JSON endpoint:

```bash
export ELMASRY_LICENSE_URL="https://example.com/licenses.json"
bash run.sh
```

Expected JSON format:

```json
{
  "KEY-123": {
    "status": "ok",
    "expiry": "2027-12-31",
    "message": "Subscription active"
  }
}
```

For subscription or support, contact: @mfathey466
