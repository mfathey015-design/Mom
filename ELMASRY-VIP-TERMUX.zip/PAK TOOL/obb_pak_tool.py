#!/usr/bin/env python3
from pathlib import Path
import base64
import json
import os
import urllib.error
import urllib.request
from datetime import date
from rich.console import Console

ROOT = Path(__file__).resolve().parent
LICENSE_URL = os.environ.get(
    "ELMASRY_LICENSE_URL",
    "https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json",
)
DEVELOPER_URL = "https://t.me/mfathey466"

console = Console(force_terminal=True, color_system="standard")


def _print_error(message: str) -> None:
    console.print(f"\n✖ {message}", style="bold red")
    console.print("For subscription or support, contact the developer: @mfathey466", style="yellow")
    console.print(f"Telegram: {DEVELOPER_URL}\n", style="magenta")


def validate_license() -> bool:
    console.print("╔════════════════════════════════════════════╗", style="bold cyan")
    console.print("║       ELMASRY VIP - License Check          ║", style="bold cyan")
    console.print("╚════════════════════════════════════════════╝", style="bold cyan")
    try:
        key = console.input("[yellow]\n🔑 Enter subscription key: [/yellow]").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return False

    if not key:
        _print_error("No subscription key was entered.")
        return False

    console.print("\n🌐 Connecting to license server...", style="bold blue")
    try:
        request = urllib.request.Request(
            LICENSE_URL,
            headers={"User-Agent": "ELMASRY-VIP-Termux/1.0", "Accept": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            licenses = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        _print_error("Could not connect to the license server. Check your internet connection and try again.")
        print(f"Details: {exc}")
        return False

    record = licenses.get(key) if isinstance(licenses, dict) else None
    if not isinstance(record, dict) or record.get("status") != "ok":
        _print_error("Invalid or inactive subscription key.")
        return False

    expiry = str(record.get("expiry", "")).strip()
    try:
        expiry_date = date.fromisoformat(expiry)
    except ValueError:
        _print_error("The subscription expiry date is invalid.")
        return False

    if expiry_date < date.today():
        _print_error(f"The subscription expired on {expiry}.")
        return False

    console.print("\n✅ Subscription key verified successfully.", style="bold green")
    console.print(record.get("message") or f"Subscription valid until {expiry}", style="green")
    return True


if not validate_license():
    raise SystemExit(1)

# The encrypted payload is decrypted only after license validation succeeds.
from Crypto.Cipher import AES

payload = (ROOT / "payload.enc").read_bytes()
try:
    source = AES.new(
        base64.b85decode("(ze;<4zx75z>y0#CTao5gn5|Um~<Wrvh2rT=#hxB"),
        AES.MODE_GCM,
        nonce=payload[:12],
    ).decrypt_and_verify(payload[28:], payload[12:28]).decode("utf-8")
except Exception as exc:
    raise RuntimeError("Encrypted tool integrity check failed") from exc

for name in (
    "ORIGINAL_PAK", "UNPACKED_FILES", "EDITTED_FILES", "EDIT_PAK", "REPACKED_PAK",
    "FOUND_FILES", "Original_OBB", "unpacked_OBB", "Repacked_OBB", "LUA_ORIGINAL",
    "DECOMPILED_LUA", "COMPILED_LUA", "LUA_REPORTS", "SM4_FINDER_SCAN", "PAK",
    "EDIT", "RESULT",
):
    (ROOT / name).mkdir(parents=True, exist_ok=True)

os.environ["OBB_PAK_TOOL_BASE_PATH"] = str(ROOT)
namespace = {"__name__": "embedded", "__file__": "<encrypted>"}
exec(compile(source, "<encrypted obb_pak_tool>", "exec"), namespace, namespace)
namespace["main"]()
