#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python -y
pip install -r requirements.txt
printf '\nInstallation completed. Start the tool with: bash run.sh\n'
