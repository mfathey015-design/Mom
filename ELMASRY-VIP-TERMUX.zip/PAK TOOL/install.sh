#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python -y
python -m pip install --upgrade pip
pip install -r requirements.txt
printf '\nتم التثبيت بنجاح. شغّل الأداة بالأمر: bash run.sh\n'
