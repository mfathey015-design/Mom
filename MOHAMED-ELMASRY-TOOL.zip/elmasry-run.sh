#!/data/data/com.termux/files/usr/bin/bash
set -Eeuo pipefail

APP_NAME="MOHAMED-ELMASRY-TOOL"
APP_DIR="$HOME/$APP_NAME"
ZIP_FILE="$APP_DIR/$APP_NAME.zip"
ZIP_URL="${ELMASRY_TOOL_URL:-https://raw.githubusercontent.com/mfathey015-design/Mom/main/MOHAMED-ELMASRY-TOOL.zip}"

red='\033[91m'
green='\033[92m'
cyan='\033[96m'
yellow='\033[93m'
reset='\033[0m'

fail() {
    printf "${red}%s${reset}\n" "Error: $*" >&2
    exit 1
}

printf "${cyan}%s${reset}\n" "${APP_NAME} - Preparing..."

command -v pkg >/dev/null 2>&1 || fail "This launcher must be run inside Termux."

pkg update -y
pkg install -y python unzip curl

rm -rf "$APP_DIR"
mkdir -p "$APP_DIR"

printf "${yellow}%s${reset}\n" "Downloading ${APP_NAME}.zip..."
curl -fL --retry 3 --retry-delay 2 --connect-timeout 15 -o "$ZIP_FILE" "$ZIP_URL" \
    || fail "Could not download the tool package."

unzip -oq "$ZIP_FILE" -d "$APP_DIR" \
    || fail "The downloaded package is not a valid ZIP archive."
rm -f "$ZIP_FILE"

PACKAGE_DIR="$APP_DIR/MOHAMED-ELMASRY-TOOL-PACKAGE"
[ -d "$PACKAGE_DIR" ] || fail "The package folder was not found in the archive."
[ -f "$PACKAGE_DIR/MOHAMED_ELMASRY_TOOL.py" ] || fail "The tool source was not found."

cd "$PACKAGE_DIR"

if [ -f requirements.txt ]; then
    python -m pip install --no-cache-dir -r requirements.txt
fi

chmod +x run.sh 2>/dev/null || true
printf "${green}%s${reset}\n" "Starting ${APP_NAME}..."
exec bash run.sh
