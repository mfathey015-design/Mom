# MOHAMED ELMASRY TOOL — Licensed Termux Edition

Complete Termux source package with subscription validation before the main menu.

## Run

```bash
bash install.sh
bash run.sh
```

The tool asks for `Enter subscription key:` and validates it against:

```text
https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json
```

The JSON `message` field is not displayed. Invalid or expired keys show:

```text
For subscription or support, contact: @mfathey466
Telegram: https://t.me/mfathey466
```

The workspace folders are included and are also created automatically under:

```text
/storage/emulated/0/MOHAMED ELMASRY
```
