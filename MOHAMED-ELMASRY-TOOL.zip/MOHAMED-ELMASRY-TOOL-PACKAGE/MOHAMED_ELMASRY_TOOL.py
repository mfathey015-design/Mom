#!/usr/bin/env python3
from pathlib import Path
import base64
import json
import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from datetime import date
from Crypto.Cipher import AES
from Crypto.PublicKey import ECC
from Crypto.Signature import eddsa
from rich.console import Console

ROOT = Path(__file__).resolve().parent
LICENSE_URL = os.environ.get(
    "ELMASRY_LICENSE_URL",
    "https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json",
)
DEVELOPER_URL = "https://t.me/mfathey466"
console = Console(force_terminal=True, color_system="standard")


def fail(message: str) -> None:
    console.print(message, style="bold red")
    console.print("For subscription or support, contact: @mfathey466", style="yellow")
    clickable = f"\033]8;;{DEVELOPER_URL}\033\\Telegram: {DEVELOPER_URL}\033]8;;\033\\"
    sys.stdout.write(f"\033[95m{clickable}\033[0m\n")
    sys.stdout.flush()
    commands = []
    termux_open = shutil.which("termux-open-url")
    if termux_open:
        commands.append([termux_open, DEVELOPER_URL])
    commands.extend([
        ["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", "tg://resolve?domain=mfathey466"],
        ["/system/bin/am", "start", "-a", "android.intent.action.VIEW", "-d", DEVELOPER_URL],
        ["am", "start", "-a", "android.intent.action.VIEW", "-d", DEVELOPER_URL],
    ])
    for command in commands:
        try:
            result = subprocess.run(command, check=False, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if result.returncode == 0:
                return
        except OSError:
            continue


def check_license() -> bool:
    console.clear()
    console.print("╔════════════════════════════════════════════╗", style="bold cyan")
    console.print("║       MOHAMED ELMASRY - LICENSE CHECK     ║", style="bold cyan")
    console.print("╚════════════════════════════════════════════╝", style="bold cyan")
    try:
        key = console.input("[yellow]\n🔑 Enter subscription key: [/yellow]").strip()
    except (EOFError, KeyboardInterrupt):
        return False
    if not key:
        fail("No subscription key was entered.")
        return False

    console.print("\nConnecting to server...", style="bold blue")
    try:
        request = urllib.request.Request(
            LICENSE_URL,
            headers={"User-Agent": "MOHAMED-ELMASRY-TERMUX/1.0", "Accept": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            licenses = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, ValueError, UnicodeDecodeError):
        fail("Could not connect to server.")
        return False

    record = licenses.get(key) if isinstance(licenses, dict) else None
    if not isinstance(record, dict) or record.get("status") != "ok":
        fail("Invalid or inactive subscription key.")
        return False

    try:
        expiry = date.fromisoformat(str(record.get("expiry", "")).strip())
    except ValueError:
        fail("Invalid subscription expiry date.")
        return False
    if expiry < date.today():
        fail("Subscription has expired.")
        return False
    return True


if not check_license():
    raise SystemExit(1)

try:
    blob_path = ROOT / "payload.enc"
    signature_path = ROOT / "payload.sig"
    public_key_path = ROOT / "payload.pub"
    payload = blob_path.read_bytes()
    public_key = ECC.import_key(public_key_path.read_bytes())
    eddsa.new(public_key, "rfc8032").verify(payload, signature_path.read_bytes())
    blob = payload
    source = AES.new(
        base64.b85decode("qy|4Ts{CHC5v2Yb3506IO8z@NyN?N)ot+b6c}A0{"),
        AES.MODE_GCM,
        nonce=blob[:12],
    ).decrypt_and_verify(blob[28:], blob[12:28]).decode("utf-8")
except Exception as exc:
    raise RuntimeError("Encrypted tool integrity check failed") from exc

namespace = {"__name__": "__main__", "__file__": str(ROOT / "MOHAMED_ELMASRY_TOOL.py")}
exec(compile(source, "<encrypted MOHAMED ELMASRY TOOL>", "exec"), namespace, namespace)
