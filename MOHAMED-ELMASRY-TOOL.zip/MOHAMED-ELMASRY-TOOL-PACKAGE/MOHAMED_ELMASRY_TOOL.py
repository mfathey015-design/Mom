#!/usr/bin/env python3
from pathlib import Path
import base64
import json
import os
import subprocess
import urllib.error
import urllib.request
from datetime import date
from Crypto.Cipher import AES
from rich.console import Console

ROOT = Path(__file__).resolve().parent
LICENSE_URL = os.environ.get(
    "ELMASRY_LICENSE_URL",
    "https://raw.githubusercontent.com/mfathey015-design/Mom/main/N5LA.json",
)
DEVELOPER_URL = "https://t.me/mfathey466"
console = Console(force_terminal=True, color_system="standard")


def fail(message: str) -> None:
    console.print(message, style="bold red")
    console.print("For subscription or support, contact: @mfathey466", style="yellow")
    console.print(f"Telegram: {DEVELOPER_URL}", style="magenta")
    try:
        choice = console.input("[cyan]Press O to open Telegram directly, or Enter to exit: [/cyan]").strip().lower()
        if choice == "o":
            subprocess.run(
                ["am", "start", "-a", "android.intent.action.VIEW", "-d", DEVELOPER_URL],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except (EOFError, KeyboardInterrupt, OSError):
        pass


def check_license() -> bool:
    console.clear()
    console.print("╔════════════════════════════════════════════╗", style="bold cyan")
    console.print("║       MOHAMED ELMASRY - LICENSE CHECK     ║", style="bold cyan")
    console.print("╚════════════════════════════════════════════╝", style="bold cyan")
    try:
        key = console.input("[yellow]\n🔑 Enter subscription key: [/yellow]").strip()
    except (EOFError, KeyboardInterrupt):
        return False
    if not key:
        fail("No subscription key was entered.")
        return False

    console.print("\nConnecting to server...", style="bold blue")
    try:
        request = urllib.request.Request(
            LICENSE_URL,
            headers={"User-Agent": "MOHAMED-ELMASRY-TERMUX/1.0", "Accept": "application/json"},
        )
        with urllib.request.urlopen(request, timeout=15) as response:
            licenses = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, ValueError, UnicodeDecodeError):
        fail("Could not connect to server.")
        return False

    record = licenses.get(key) if isinstance(licenses, dict) else None
    if not isinstance(record, dict) or record.get("status") != "ok":
        fail("Invalid or inactive subscription key.")
        return False

    try:
        expiry = date.fromisoformat(str(record.get("expiry", "")).strip())
    except ValueError:
        fail("Invalid subscription expiry date.")
        return False
    if expiry < date.today():
        fail("Subscription has expired.")
        return False
    return True


if not check_license():
    raise SystemExit(1)

try:
    blob = (ROOT / "payload.enc").read_bytes()
    source = AES.new(
        base64.b85decode("JzLXMS^0&tCH};`+ZMMkJrlhuJUR}CYsumXZy|tv"),
        AES.MODE_GCM,
        nonce=blob[:12],
    ).decrypt_and_verify(blob[28:], blob[12:28]).decode("utf-8")
except Exception as exc:
    raise RuntimeError("Encrypted tool integrity check failed") from exc

namespace = {"__name__": "__main__", "__file__": str(ROOT / "MOHAMED_ELMASRY_TOOL.py")}
exec(compile(source, "<encrypted MOHAMED ELMASRY TOOL>", "exec"), namespace, namespace)
