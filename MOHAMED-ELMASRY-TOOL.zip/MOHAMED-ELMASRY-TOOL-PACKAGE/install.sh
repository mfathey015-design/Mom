#!/data/data/com.termux/files/usr/bin/bash
set -e
pkg update -y
pkg install python -y
python -m pip install --no-cache-dir -r requirements.txt
printf '\nInstallation completed. Start with: bash run.sh\n'
