#!/data/data/com.termux/files/usr/bin/bash
set -e
cd "$(dirname "$0")"
export TERM="${TERM:-xterm-256color}"
exec python MOHAMED_ELMASRY_TOOL.py
