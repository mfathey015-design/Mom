#!/usr/bin/env python3
"""Original LUA-TOOL with only its two legacy Lua actions redirected to Tool 6."""
from pathlib import Path
import importlib.util, importlib.machinery, sys
import os, shutil, tempfile, subprocess, zlib, struct

BASE = Path(__file__).resolve().parent
original = BASE / "LUA-TOOL@mfathey.pyc.old"
component = BASE / "tool6_component.dat"
tool2_component = BASE / "tool2_repack_component.dat"
if not original.exists():
    original = BASE / "LUA-TOOL@mfathey.pyc"
if not original.exists():
    raise SystemExit("Original LUA-TOOL bytecode was not found")
if not component.exists():
    raise SystemExit("Tool 6 component data was not found")
if not tool2_component.exists():
    raise SystemExit("Tool 2 component data was not found")

loader = importlib.machinery.SourcelessFileLoader("lua_original", str(original))
spec = importlib.util.spec_from_file_location("lua_original", str(original), loader=loader)
mod = importlib.util.module_from_spec(spec)
sys.modules["lua_original"] = mod
spec.loader.exec_module(mod)
# Compatibility bridge: Tool 6 expects these shared names from its original host.
mod.BASE_DIR = BASE
for _name, _value in {"os": os, "shutil": shutil, "tempfile": tempfile, "subprocess": subprocess, "zlib": zlib, "struct": struct, "Path": Path}.items():
    mod.__dict__.setdefault(_name, _value)
if "ui_print" not in mod.__dict__:
    mod.ui_print = getattr(mod, "print", getattr(mod, "console").print)
# Execute only the transferred Tool 6 component inside the original namespace.
_aes_key = "9d4c7a2f08c3e1b6a54f9012d77b3e6c8f1a0d4e5b6c7d8e9f1029384756a1bc"
_aes_iv = "4e7a19c2a86d3f5071b4c9e2d8a6f031"
_dec_data = subprocess.run(
    ["openssl", "enc", "-d", "-aes-256-cbc", "-K", _aes_key, "-iv", _aes_iv],
    input=component.read_bytes(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True
).stdout
code = compile(_dec_data, "<tool6_component>", "exec")
exec(code, mod.__dict__, mod.__dict__)
del _aes_key, _aes_iv, _dec_data, code
# Load the transferred Mohamed Elmasry Repack implementation in an isolated namespace.
_tool2_key = "9d4c7a2f08c3e1b6a54f9012d77b3e6c8f1a0d4e5b6c7d8e9f1029384756a1bc"
_tool2_iv = "8b2e4c7d91a6f3052c8e7b1d4f9a603e"
_tool2_ns = {"__name__": "__transferred_tool2_repack__", "__file__": str(tool2_component), "_HOST_BASE": BASE}
_tool2_plain = subprocess.run(
    ["openssl", "enc", "-d", "-aes-256-cbc", "-K", _tool2_key, "-iv", _tool2_iv],
    input=tool2_component.read_bytes(), stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True
).stdout
exec(compile(_tool2_plain, "<tool2_repack_component>", "exec"), _tool2_ns, _tool2_ns)
def _repack_option2_bridge(data_path=None, unpack_entry=None, *_args, **_kwargs):
    selected_name = getattr(unpack_entry, "name", unpack_entry)
    return _tool2_ns["screen_repack"](selected_name)
mod.do_repack_from_unpack = _repack_option2_bridge
mod.__dict__["do_repack_from_unpack"] = _repack_option2_bridge
# Make the original option-2 selector read the transferred EDIT_PAK workspace.
def _option2_folders():
    edit_root = BASE / "EDIT_PAK"
    return sorted((p for p in edit_root.iterdir() if p.is_dir()), key=lambda p: p.name.lower()) if edit_root.exists() else []
mod.detect_unpacked_paks = _option2_folders
mod.__dict__["detect_unpacked_paks"] = _option2_folders
del _tool2_key, _tool2_iv, _tool2_plain

# The original menu's choices 8 and 9 now both open the complete Tool 6 submenu.
def _tool6_bridge(data_path):
    return mod.run_lua_tool6()
mod.lua_decompile_menu = _tool6_bridge
mod.lua_compile_menu = _tool6_bridge
mod.__dict__["lua_decompile_menu"] = _tool6_bridge
mod.__dict__["lua_compile_menu"] = _tool6_bridge

def _patch_menu_labels(code):
    """Replace only the two legacy Lua labels in the original menu."""
    import types
    consts = list(code.co_consts)
    changed = False
    for i, value in enumerate(consts):
        if isinstance(value, tuple) and any(
            isinstance(x, tuple) and len(x) == 2 and x[1] in ("LUA DECOMPILE", "LUA COMPILE")
            for x in value
        ):
            kept = []
            for item in value:
                if isinstance(item, tuple) and len(item) == 2 and item[1] in ("LUA DECOMPILE", "LUA COMPILE"):
                    if not any(isinstance(x, tuple) and len(x) == 2 and x[1] == "LUA TOOL" for x in kept):
                        kept.append(("[8]", "LUA TOOL"))
                else:
                    kept.append(item)
            consts[i] = tuple(kept)
            changed = True
    nested = []
    for value in consts:
        nested.append(_patch_menu_labels(value) if isinstance(value, types.CodeType) else value)
    if changed or any(a is not b for a,b in zip(nested, code.co_consts)):
        consts = nested
        return code.replace(co_consts=tuple(consts))
    return code

if hasattr(mod, "main_menu"):
    mod.main_menu.__code__ = _patch_menu_labels(mod.main_menu.__code__)
# Tool 6 creates its own workspaces only after the user selects it.
mod.main()
