#!/data/data/com.termux/files/usr/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec python3 "$BASE/LUA-TOOL@mfathey_merged.py"
